# Atom Learning Devops Exercise

Welcome to the Atom Learning devops interview exercise! Congratulations on reaching this stage in our interview process and thank you for taking the time to complete this challenge.

The challenge consists of a series of tasks to be carried out on a Kubernetes cluster. You can do these on any locally-hosted Kubernetes cluster but we recommend using `minikube`. 

## Setup (15mins)
* First, install minikube if you don't already have it. Follow the guide here: https://minikube.sigs.k8s.io/docs/start/
* Next clone this repository to your local machine
* Enable the `ingress` addon for minikube (or otherwise install NGINX ingress if not using minikube: https://kubernetes.github.io/ingress-nginx/deploy)
  * `minikube addons enable ingress`
* From within the root folder of this repo, apply all the yamls `kubectl apply -f ./yamls`
* Finally, set up your machine to point `atomlearning.local` to your cluster:
  * Run `minikube ip` to get the IP of your cluster
  * Add `<your ip> atomlearning.local` to your `/etc/hosts` file (or equivalent)
  * Verify it's working by going to `http://atomlearning.local/` in a browser. You should see a NGINX 404 Not Found page

# Tasks
Please complete all tasks. We've put a rough time indication at the end to give an idea of the complexity, but we do not look at commit times when assessing your responses.

** Please commit after each task and put the task number in the commit message **

1. Change the `backend` deployment to run on port `4444` [5 mins]
2. Change the configuration of the `frontend` and `backend` deployments so that they are given "Guaranteed" status by the K8 cluster. [5 mins]
3. Add auto-scaling to both the `frontend` and `backend` deployments. Each deployment should scale from 2 replicas to 4 when the CPU utilisation is over 40%. [10 mins]
4. Add Ingress objects to make the frontend and backend available on `atomlearning.local`. The frontend should be accessible at `http://atomlearning.local` and the backend at `http://atomlearning.local/api`. _You will need to configure some additional options in your ingress to get this work (hint: the backend has no knowledge of the URL it's hosted on). Once completed you should be able to see a website in a browser instead of 404 Not Found page_. [20 mins]
5. Add liveness and readiness probes to the `backend` deployment to ensure it's always available. (hint: there is a `/health` endpoint). [10  mins]
6. Write a bash script (placeholder file saved in `./bash/fetch_questions.sh`) that fetches 10 random questions from the `backend` deployment and saves them to a single JSON file. Include an example output file in your commit. _You will need explore the web app to identify correct api path to use for this task_ [15-30 mins]
