# helm-chart

This helm chart contains the manifests for atom-learning backend

# kubectl create namespace atom 
# helm install backend  backend/ -n atom