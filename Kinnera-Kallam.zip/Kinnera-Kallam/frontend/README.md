# helm-chart

This helm chart contains the manifests for atom-learning front end

helm install frontend  frontend/ -n atom