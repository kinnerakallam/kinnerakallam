# helm-chart

This helm chart contains the manifests for atom-learning ingress

kubectl apply -f ingress-rules/atom.yaml